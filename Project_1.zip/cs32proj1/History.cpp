//
//  History.cpp
//  cs32 project 1
//
//  Created by Janvi Bharucha on 4/5/23.
//

#include <stdio.h>
#include <iostream>
#include "History.h"

using namespace std;

History::History(int nRows, int nCols)
{
    m_rows = nRows;
    m_cols = nCols;
    for (int r = 1; r <= nRows; r++) {
        for (int c = 1; c <= nCols; c++)
        {
            m_arena[r-1][c-1] = '.';
        }
    }
}

bool History::record(int r, int c)
{
    if ( r > m_rows || r < 1 || c > m_cols || c < 1)
    {
        return false;
    }
    
    if (m_arena[r-1][c-1] == '.')
    {
        m_arena[r-1][c-1] = 'A';
    }
    else if (m_arena[r-1][c-1] >= 'A' && m_arena[r-1][c-1] <= 'Y')
    {
        m_arena[r-1][c-1]++;
    }
    else if (m_arena[r-1][c-1] == 'Z')
    {
        return true;
    }
    return true;
}

void History::display() const
{
    clearScreen();
    for (int r = 1; r <= m_rows; r++)
    {
        for (int c = 1; c <= m_cols; c++)
        {
            cout << m_arena[r-1][c-1];
        }
        cout << endl;
    }
    cout << endl;
}
//History::History(int nRows, int nCols){//create an array of periods char array
//    if (nRows == Arena.rows() && nCols == Arena.columns() )
//}

//record
//rabbit move function in rabbit cpp
// figure out where to call it
//if Z return true add to code

//clear screen
//print history grid
//empty line cout endl
//press enter to continue --> within arena.cpp


//use intialization list when using history in arena bc no default constructor

//[r-1][c-1] == '.'

//History& Arena:: history()
//{
//    return m_history;
//}

//arena cpp

