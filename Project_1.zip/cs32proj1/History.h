//
//  History.h
//  cs32 project 1
//
//  Created by Janvi Bharucha on 4/5/23.
//

#ifndef History_h
#define History_h
#include "globals.h"

class History
    {
    private:
        int m_rows;
        int m_cols;
        char m_arena[MAXROWS][MAXCOLS];
      public:
        History(int nRows, int nCols);
        bool record(int r, int c);
        void display() const;
    };

#endif /* History_h */
