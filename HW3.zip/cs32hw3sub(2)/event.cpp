//
//  main.cpp
//  cs32hw3(1)
//
//  Created by Janvi Bharucha on 5/4/23.
//


class Event {
public:
    Event(string name):mName(name){}
    string name() const {
        return mName;
    }
    virtual bool isSport() const = 0;
    virtual string need() const = 0;
    virtual ~Event(){}
private:
    string mName;
};

class Concert:public Event {
public:
    Concert (string artist, string genre):Event(artist){
        mGenre = genre;
    }
    virtual bool isSport () const {return false;}
    virtual string need() const {return "a stage";}
    virtual ~Concert() {
        cout << "Destroying the " << name() << " " << mGenre << " concert"<<endl;
    }
private:
    string mGenre;
};

class BasketballGame: public Event{
public:
    BasketballGame(string game):Event(game){}
    virtual bool isSport() const {return true;}
    virtual string need() const { return "hoops";}
    virtual ~BasketballGame() {
        cout << "Destroying the " << name() << " basketball game"<< endl;
    }
};

class HockeyGame: public Event {
public:
    HockeyGame(string game): Event(game){}
    virtual bool isSport() const {return true;}
    virtual string need() const { return "ice";}
    virtual ~HockeyGame() {
        cout << "Destroying the " << name() << " hockey game" << endl;
    }
};
