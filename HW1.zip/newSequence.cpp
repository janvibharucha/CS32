//
//  Sequence.cpp
//  CS 32 HW # 1 (1, 2)
//
//  Created by Janvi Bharucha on 4/14/23.
//

#include <stdio.h>
#include "newSequence.h"
using namespace std;

Sequence::Sequence(){
    m_array_counter = 0;
    m_max_size = DEFAULT_MAX_ITEMS;
    m_array = new ItemType[DEFAULT_MAX_ITEMS];
}

Sequence::Sequence(int max_size){
    if (max_size < 0)
        exit(1);
    m_array_counter = 0;
    m_max_size = max_size;
    m_array = new ItemType[max_size];
}

Sequence::Sequence (const Sequence &other){
    m_array_counter = other.m_array_counter;
    m_max_size = other.m_max_size;
    m_array = new ItemType[m_max_size];
    
    for (int i = 0; i < m_array_counter; i++)
        m_array[i] = other.m_array[i];
}

Sequence::~Sequence() {
    delete[] m_array;
}

Sequence& Sequence::operator= (const Sequence& value) {
    if (this != &value) {
        delete[] m_array;
        m_array_counter = value.m_array_counter;
        m_max_size = value.m_max_size;
        m_array = new ItemType[m_max_size];
        
        for (int i = 0; i < size(); i++)
            m_array[i] = value.m_array[i];
    }
    return *this;
}

bool Sequence::empty() const {
    return m_array_counter == 0;
}

int Sequence::size() const {
    return m_array_counter;
}

int Sequence::insert(int pos, const ItemType& value){
    if (0 <= pos && pos <= size() && size() < m_max_size) {
        if (pos == size()) {
            m_array[pos] = value;
            m_array_counter++;
            return pos;
        }
        
        if (pos < size()) {
            for (int i = size()-1; i >= pos; i--) {
                m_array[i+1] = m_array[i];
            }
            m_array[pos] = value;
            m_array_counter++;
            return pos;
        }
    }
    return -1;
}

int Sequence::insert(const ItemType& value){
    if (size() >= m_max_size)
        return -1;
    int p = 0;
    while (p < size() && m_array[p] < value) {
        p++;
    }
    
    if (p < size()) {
        for (int i = size() - 1 ; i >= p; i--) {
            m_array[i+1] = m_array[i];
        }
    }
    m_array[p] = value;
    m_array_counter++;
    return p;
}

bool Sequence::erase(int pos) {
    if (pos >= size() || pos < 0) {
        return false;
    }
    
    for (int i = pos; i < size()-1; i++) {
        m_array[i] = m_array[i+1];
    }
    m_array_counter--;
    return true;
}
  
int Sequence::remove(const ItemType& value){ // double check
    int items_removed = 0;
    for (int i = 0; i < size(); i++){
        if (m_array[i] == value) {
            for (int j = i; j < size() - 1; j++) {
                m_array[j] = m_array[j+1];
            }
            m_array_counter--;
            items_removed++;
            i--;
        }
    }
    return items_removed;
}

bool Sequence::get(int pos, ItemType& value) const {
    if (pos >= size() || pos < 0)
        return false;
    value = m_array[pos];
    return true;
}

bool Sequence:: set(int pos, const ItemType& value){
    if (pos >= size() || pos < 0)
        return false;
//    if (m_array[pos] == "") how do you increment counter?
//        m_array_counter++;
    m_array[pos] = value;
    return true;
}
  
int Sequence::find(const ItemType& value) const{
    int p = -1;
    for (int i = 0; i < size(); i++) {
        if (m_array[i] == value) {
            p = i;
            break;
        }
    }
    return p;
}

void Sequence::swap(Sequence& other) { // double check the limits on the for loops
    
    int temp_array_counter = m_array_counter;
    m_array_counter = other.m_array_counter;
    other.m_array_counter = temp_array_counter;
    
    ItemType *t = other.m_array;
    other.m_array = this->m_array;
    m_array = t;
    
    int temp_max_size = m_max_size;
    m_max_size = other.m_max_size;
    other.m_max_size = temp_max_size;
    
}
