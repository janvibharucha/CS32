//
//  testRainfallList.cpp
//  CS 32 HW # 1 (1, 2)
//
//  Created by Janvi Bharucha on 4/16/23.
//

#include <stdio.h>
#include "RainfallList.h"
#include <cassert>

int main() {
    RainfallList rainfall;
    
    assert (rainfall.add(1));
    assert (rainfall.add(3));
    assert (rainfall.remove(1));
    assert (rainfall.size() == 1);
    assert (rainfall.add(10));
    assert (rainfall.minimum() == 3);
    assert (rainfall.maximum() == 10);
    std::cerr << "passed"<< std::endl;
}

