#include "Sequence.h"
      #include <iostream>
      #include <cassert>
      using namespace std;

      void test()
      {
          Sequence s;
          assert (s.empty());
          s.insert(0, 10);
          s.insert(0, 20);
          assert(s.size() == 2);
          s.insert(15);
          assert(s.find(15) == 0);
          ItemType x = 999;
          assert(s.get(0, x) && x == 15);
          assert(s.get(1, x) && x == 20);
          assert(s.remove(15));
          assert(s.get(0, x) && x == 20);
          s.set(0, 12);
          assert (s.get(0,x) && x ==12);
          
          Sequence t;
          assert(t.empty());
          t.insert(0,1);
          t.insert(0,2);
          t.insert(0,3);
          t.swap(s);
          assert(t.get(0,x) && x == 12);
          
      }

      int main()
      {
          test();
          cout << "Passed all tests" << endl;
      }
