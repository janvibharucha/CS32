#include "newSequence.h"
        #include <iostream>
        #include <cassert>
        using namespace std;

        void test()
        {
            Sequence s;
            s.insert(0, 10);
            s.insert(0, 20);
            assert(s.size() == 2);
            ItemType x = 999;
            assert(s.get(0, x) && x == 20);
            assert(s.get(1, x) && x == 10);
            
            Sequence t (s);
            assert (t.get(0, x) && x == 20);
            assert (t.get(1,x) && x == 10);
            assert (t.size() == 2);
            
            Sequence r = t;
            assert (r.get(0,x) && x == 20);
            assert (r.size() == 2);
            assert (r.find(10) == 1);
            r.insert(0,30);
            assert (r.find(30) == 0);
            
            t.swap(r);
            assert (t.find(30) == 0);
            assert (t.size() == 3);
        }

        int main()
        {
            test();
            
            cout << "Passed all tests" << endl;
        }
