//
//  RainfallList.cpp
//  CS 32 HW # 1 (1, 2)
//
//  Created by Janvi Bharucha on 4/16/23.
//

#include <stdio.h>
#include "RainfallList.h"

RainfallList::RainfallList() {}

bool RainfallList::add(unsigned long rainfall) {
    if (rainfall <= 400 && rainfall >=0 && m_list.size() < DEFAULT_MAX_ITEMS) {
        m_list.insert(rainfall);
        return true;
    }
    return false;
}
  

int RainfallList::size() const{
    return m_list.size();
}

unsigned long RainfallList::minimum() const{
    if (m_list.empty())
        return NO_RAINFALLS;
        
    for (unsigned long i = 0; i <= 400; i++){
        if (m_list.find(i) != -1)
            return i;
        }
    return NO_RAINFALLS;
}
        

unsigned long RainfallList::maximum() const{
     if (m_list.empty())
         return NO_RAINFALLS;
        for (unsigned long i = 400; i >=0; i--) {
            if (m_list.find(i) != -1)
                return i;
        }
    return NO_RAINFALLS;
}
  
bool RainfallList::remove(unsigned long rainfall) { 
    if (m_list.erase(m_list.find(rainfall)))
        return true;
        
    return false;
}
