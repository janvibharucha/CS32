//
//  Sequence.cpp
//  CS 32 HW # 1 (1, 2)
//
//  Created by Janvi Bharucha on 4/14/23.
//

#include <stdio.h>
#include "Sequence.h"

Sequence::Sequence(){
    m_array_counter = 0;
}

bool Sequence::empty() const {
    return m_array_counter == 0;
}

int Sequence::size() const {
    return m_array_counter;
}

int Sequence::insert(int pos, const ItemType& value){
    if (0 <= pos && pos <= size() && size() < DEFAULT_MAX_ITEMS) {
        if (pos == size()) {
            m_array[pos] = value;
            m_array_counter++;
            return pos;
        }
        
        if (pos < size()) {
            for (int i = size()-1; i >= pos; i--) {
                m_array[i+1] = m_array[i];
            }
            m_array[pos] = value;
            m_array_counter++;
            return pos;
        }
    }
    return -1;
}

int Sequence::insert(const ItemType& value){
    if (size() >= DEFAULT_MAX_ITEMS)
        return -1;
    int p = 0;
    while (p < size()-1 && m_array[p] < value) {
        p++;
    }
    
    if (p < size()) {
        for (int i = size() - 1 ; i >= p; i--) {
            m_array[i+1] = m_array[i];
        }
    }
    m_array[p] = value;
    m_array_counter++;
    return p;
}

bool Sequence::erase(int pos) {
    if (pos >= size() || pos < 0) {
        return false;
    }
    
    for (int i = pos; i < size(); i++) {
        m_array[i] = m_array[i+1];
    }
    m_array_counter--;
    return true;
}
  
int Sequence::remove(const ItemType& value){
    int items_removed = 0;
    for (int i = 0; i < size(); i++){
        if (m_array[i] == value) {
            for (int j = i; j < size() - 1; j++) {
                m_array[j] = m_array[j+1];
            }
            m_array_counter--;
            items_removed++;
            i--;
        }
    }
    return items_removed;
}

bool Sequence::get(int pos, ItemType& value) const {
    if (pos >= size() || pos < 0)
        return false;
    value = m_array[pos];
    return true;
}

bool Sequence:: set(int pos, const ItemType& value){
    if (pos >= size() || pos < 0)
        return false;
    m_array[pos] = value;
    return true;
}
  
int Sequence::find(const ItemType& value) const{
    int p = -1;
    for (int i = 0; i < size(); i++) {
        if (m_array[i] == value) {
            p = i;
            break;
        }
    }
    return p;
}

void Sequence::swap(Sequence& other) { 
    int larger = (this->size() > other.size()) ? this->size() : other.size();

        for (int i = 0; i < larger; i++) {
            ItemType t = other.m_array[i];
            other.m_array[i] = this->m_array[i];
            this->m_array[i] = t;
        }

    int temp_array_counter = m_array_counter;
    m_array_counter = other.m_array_counter;
    other.m_array_counter = temp_array_counter;
}
