//
//  main.cpp
//  cs32 hw 2 (5)
//
//  Created by Janvi Bharucha on 4/29/23.
//

#include <iostream>
#include <stack>
#include <string>
#include <cassert>

using namespace std;

bool ValidInfix (string infix);
void InfixToPostfix (string infix, string& postfix);
bool PostfixEval (string postfix);
int precedence (char c);

int evaluate(string infix, string& postfix, bool& result) {
    if (!ValidInfix(infix))
        return 1;
    InfixToPostfix(infix, postfix);
    result = PostfixEval(postfix);
    return 0;
}


// function to check if infix is valid
bool ValidInfix (string infix) {
    
    string nospaceInfix = ""; // make a new infix string that doesn't include spaces
    for (int i = 0; i < infix.size(); i++)
    {
        if (infix[i] != ' ')
        {
            nospaceInfix += infix[i]; // add values to new string if it is not a space
        }
    }
    infix = nospaceInfix; // make infix the nospaceinfix string
    
    if (infix.empty()) //if infix string is empty return false
        return false;
    
    for (int i = 0; i < infix.size(); i++){ //check only valid characters are part of the string
        if (infix[i] != '!' && infix[i] != '^' && infix[i] != '&' && infix[i] != '(' && infix[i] != ')' && infix[i] != 'T' && infix[i] != 'F')
            return false;
    }
    if (infix[0] == '&' ||infix[0] == '^' || infix[0] == ')') //check it does not start with anything other than T or F or ( or !
        return false;
    if (infix[infix.size()-1] == '&' || infix[infix.size()-1] == '^' || infix[infix.size()-1] == '(' || infix[infix.size()-1] == '!') //check it does not end with an invalid character
        return false;
   
    int startPar = 0; // ( count
    int endPar = 0; // ) count
    
    for (int i = 0; i < infix.size(); i++){
        switch (infix[i])
        {
        case '!':
                if (i - 1 >= 0) {
                    if ((infix[i-1] == ')' || infix[i-1] == 'T' || infix[i-1] == 'F'))
                        return false;
                }

            if (i + 1 < infix.size())
            {
                switch (infix[i + 1])
                {
                case ')':
                case '&':
                case '^':
                    return false;
                default:
                    break;
                        
                }
            }
            break;
        case '&':
            if (i - 1 >= 0) {
                if ((infix[i-1] == '(' || infix[i-1] == '&' || infix[i-1] == '!' || infix[i-1] == '^'))
                    return false;
            }

            if (infix[i+1] == ')'){ // necessary?
                return false;
            }
            break;
        case '^':
            if (i - 1 >= 0) {
                if ((infix[i-1] == '(' || infix[i-1] == '&' || infix[i-1] == '!' || infix[i-1] == '^'))
                    return false;
            }
            if (i + 1 < infix.size())
            {
                switch (infix[i + 1])
                {
                case '&':
                case '^':
                case ')':
                    return false;
                default:
                    break;
                }
            }
            break;
        case '(':
            startPar++;
            if (i - 1 >= 0) {
                if ((infix[i-1] == ')' || infix[i-1] == 'T' || infix[i-1] == 'F'))
                    return false;
            }
            break;
        case ')':
            if (i - 1 >= 0) {
                if ((infix[i-1] == '(' || infix[i-1] == '&' || infix[i-1] == '!' || infix[i-1] == '^'))
                    return false;
            }
            endPar++;
            if (i + 1 < infix.size())
            {
                switch (infix[i + 1])
                {
                case '!':
                    return false;
                default:
                    break;
                }
            }
            break;
        case 'F':
        case 'T':
                
            if (i - 1 >= 0) {
                if (!(infix[i-1] == '(' || infix[i-1] == '&' || infix[i-1] == '!' || infix[i-1] == '^'))
                    return false;
            }
            break;
        }
           
        if (startPar < endPar)
            return false;
    }
    
    if (startPar != endPar)
        return false;
    
    return true;
}

// int precedence function
int precedence (char c) {
    if (c == '^')
        return 1;
    if (c == '&')
        return 2;
    if (c == '!')
        return 3;
    return 4; // ??
}

//void function to evaluate infix to postfix if infix is valid
void InfixToPostfix (string infix, string& postfix) {
    postfix = ""; // initialize postfix to empty
    stack<char> operators; // initialize operator stack to empty
    string nospaceInfix = ""; // make a new infix string that doesn't include spaces
    for (int i = 0; i < infix.size(); i++)
    {
        if (infix[i] != ' ')
            nospaceInfix += infix[i]; // add values to new string if it is not a space
        
    }
    infix = nospaceInfix; // make infix the nospaceinfix string
    
    for (int i = 0; i < infix.size(); i++){
        char ch = infix[i];
        switch (ch) {
            case 'T':
            case 'F':
                postfix += ch;
                break;
            case '(':
                operators.push(ch);
                break;
            case ')':
                while (operators.top()!='('){
                    char temp = operators.top();
                    operators.pop();
                    postfix += temp;
                }
                operators.pop();
                break;
            case '!':
                while (!operators.empty() && operators.top()!='(' && precedence(ch) < precedence (operators.top())){
                    postfix += operators.top();
                    operators.pop();
                }
                operators.push(ch);
                break;
            default:
                while (!operators.empty() && operators.top()!='(' && precedence(ch) <= precedence (operators.top())){
                    postfix += operators.top();
                    operators.pop();
                }
                operators.push(ch);
                break;
        }
    }
    while (!operators.empty()){
        postfix += operators.top();
        operators.pop();
    }
}

bool PostfixEval (string postfix) {
    stack<bool> operands;
    operands.push(false);
    
    for (int i = 0; i < postfix.size(); i++){
        char ch = postfix[i];
        if (ch == 'T')
            operands.push(true);
        else if (ch == 'F')
            operands.push(false);
        else if (ch == '!') {
            int count = 1;
            while (i + count < postfix.size() && postfix[i + count] == '!') {
                count++;
            }
            if (count % 2 == 0) {
                // if there are an even number of consecutive ! operators, the result is as is
            } else {
                // if there are an odd number of consecutive ! operators, negate the top element of the stack
                bool temp = operands.top();
                operands.pop();
                bool result = !temp;
                operands.push(result);
            }
            i += count - 1; // skip over the consecutive ! operators
        }
        else if (ch == '&') {
            bool temp1 = operands.top();
            operands.pop();
            bool temp2 = operands.top();
            operands.pop();
            operands.push(temp1 && temp2);
        }
        else if (ch == '^') {
            bool temp1 = operands.top();
            operands.pop();
            bool temp2 = operands.top();
            operands.pop();
            operands.push(temp1 ^ temp2);
        }
        
    }
    return operands.top();
}


int main() {
    string pf;
    bool answer;
    
    assert(evaluate("T^ F", pf, answer) == 0  &&  pf == "TF^"  &&  answer);
    assert(evaluate("T^", pf, answer) == 1);
    assert(evaluate("F F", pf, answer) == 1);
    assert(evaluate("TF", pf, answer) == 1);
    assert(evaluate("()", pf, answer) == 1);
    assert(evaluate("()T", pf, answer) == 1);
    assert(evaluate("T(F^T)", pf, answer) == 1);
    assert(evaluate("T(&T)", pf, answer) == 1);
    assert(evaluate("(T&(F^F)", pf, answer) == 1);
    assert(evaluate("T|F", pf, answer) == 1);
    assert(evaluate("", pf, answer) == 1);
    assert(evaluate("F  ^  !F & (T&F) ", pf, answer) == 0
                         &&  pf == "FF!TF&&^"  &&  answer==false);
    assert(evaluate(" F  ", pf, answer) == 0 &&  pf == "F"  &&  !answer);
    assert(evaluate("((T))", pf, answer) == 0 &&  pf == "T"  &&  answer);
    assert (evaluate("TF", pf, answer) == 1);
    assert (evaluate("((T)", pf, answer) == 1);
    assert (evaluate("(F))", pf, answer) == 1);
    assert (evaluate("!(F^T)", pf, answer) == 0 && !answer);
    assert (evaluate("!!T", pf, answer) == 0 && answer);
    assert (evaluate("!!!F", pf, answer) == 0 && answer);
    assert (evaluate("!(!!F)", pf, answer) == 0 && answer);
    assert (evaluate("!T!", pf, answer) == 1);
    assert (evaluate("T", pf, answer) == 0 && answer);
    assert (evaluate("T(T)", pf, answer) == 1);
    assert (evaluate("T^^F", pf, answer) == 1);
    assert (evaluate("T&&F", pf, answer) == 1);
    assert (evaluate("T&F&", pf, answer) == 1);
    assert (evaluate("T&F^", pf, answer) == 1);
    assert (evaluate("T^F^", pf, answer) == 1);
    assert (evaluate("!!!!!!!!!!T", pf, answer) == 0 && answer);
    assert (evaluate("(T^F)^T", pf, answer) == 0 && !answer);
    assert (evaluate("T^F^T", pf, answer) == 0 && !answer);
    assert (evaluate("", pf, answer) == 1);
    assert (evaluate("acbsc", pf, answer) ==1);
    assert (evaluate("h^F", pf, answer) == 1);
              cout << "Passed all tests" << endl;
}
