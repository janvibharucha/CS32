//
//  main.cpp
//  cs32 hw 2 (2)
//
//  Created by Janvi Bharucha on 4/28/23.
//

#include <iostream>
#include <queue>
using namespace std;

bool pathExists(char maze[][10], int sr, int sc, int er, int ec);
          // Return true if there is a path from (sr,sc) to (er,ec)
          // through the maze; return false otherwise

class Coord
        {
          public:
            Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
            int r() const { return m_r; }
            int c() const { return m_c; }
          private:
            int m_r;
            int m_c;
        };


int main() {
    char maze[10][10] = {
        { 'X','X','X','X','X','X','X','X','X','X' },
        { 'X','.','.','.','X','.','.','.','.','X' },
        { 'X','.','.','X','X','.','X','X','.','X' },
        { 'X','.','X','.','.','.','.','X','X','X' },
        { 'X','X','X','X','.','X','X','X','.','X' },
        { 'X','.','.','X','.','.','.','X','.','X' },
        { 'X','.','.','X','.','X','.','.','.','X' },
        { 'X','X','.','X','.','X','X','X','X','X' },
        { 'X','.','.','.','.','.','.','.','.','X' },
        { 'X','X','X','X','X','X','X','X','X','X' }
    };

    if (pathExists(maze, 3,4, 8,1))
        cout << "Solvable!" << endl;
    else
        cout << "Out of luck!" << endl;
    
}

bool pathExists(char maze[][10], int sr, int sc, int er, int ec) {
    queue <Coord> c;
    c.push(Coord(sr, sc));
    maze[sr][sc] = 'm';
    
    while (!c.empty()){
        Coord temp = c.front();
        int c_R = temp.r();
        int c_C = temp.c();
        cout << "(" << c_R << ", " << c_C << ")" << endl;
        c.pop();
        
        if (c_R == er && c_C == ec)
            return true;
        if (maze[c_R+1][c_C] != 'X' && maze[c_R+1][c_C] != 'm' && maze[c_R+1][c_C] == '.') { //south
            c.push(Coord(c_R+1, c_C));
            maze[c_R+1][c_C] = 'm';
        }
        
        if (maze[c_R][c_C+1] != 'X' && maze[c_R][c_C+1] != 'm' && maze[c_R][c_C+1] == '.' ) { //east
            c.push(Coord(c_R, c_C+1));
            maze[c_R][c_C+1] = 'm';
        }
        if (maze[c_R-1][c_C] != 'X' && maze[c_R-1][c_C] != 'm' && maze[c_R-1][c_C] == '.') { //north
            c.push(Coord(c_R-1, c_C));
            maze[c_R-1][c_C] = 'm';
        }
        if (maze[c_R][c_C-1] != 'X' && maze[c_R][c_C-1] != 'm' && maze[c_R][c_C-1] == '.') { //west
            c.push(Coord(c_R, c_C-1));
            maze[c_R][c_C-1] = 'm';
        }
        
    }
    return false;
}
