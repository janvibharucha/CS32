//
//  Player.cpp
//  cs32 proj 3
//
//  Created by Janvi Bharucha on 5/19/23.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include "Player.h"

using namespace std;

Player::Player(string name):mName(name){}
//    Create a Player with the indicated name.

string Player::name() const{
    return mName; 
}
//    Return the name of the player.

bool Player::isInteractive() const{
    return false; // double check
}
//    Return false if the player is a computer player. Return true if the player is human. Most kinds of players will be computer players.
Player::~Player(){}

HumanPlayer::HumanPlayer(string name):Player(name){}

bool HumanPlayer::isInteractive() const {
    return true;
}

int HumanPlayer::chooseMove(const Board& b, Side s) const {
    int holes_that_have_beans = 0; //check that there is at least one hole that has one or more beans
    for (int i = 1; i <= b.holes(); i++){
        if (b.beans(s, i) != 0)
            holes_that_have_beans++;
    }
    if (holes_that_have_beans == 0)
        return -1; //if all the holes are empty, set to -1, indicating that no move is possible
    cout << name() << ", choose what hole you would like to begin your turn with (enter a valid integer value): "; //prompt the user
    int playerMove;
    cin >> playerMove; //store the user's input in playerMove
    
    if (playerMove <= 0 || playerMove > b.holes() || b.beans(s, playerMove) <= 0)
        return chooseMove(b, s); //if the user did not input a valid hole value then re-prompt the user until they do
    return playerMove; // return the valid hole that the user inputted
}
//A HumanPlayer chooses its move by prompting a person running the program for a move (reprompting if necessary until the person enters a valid hole number), and returning that choice. We will never test for a situation where the user doesn't enter an integer when prompted for a hole number. (The techniques for dealing with the issue completely correctly are a distraction to this project, and involve either a function like stoi or strtol, or the type istringstream.)

BadPlayer::BadPlayer(string name):Player(name){}

int BadPlayer::chooseMove(const Board& b, Side s) const{
    int badplayerMove = -1; //set initially to -1, where -1 indicates that there are no valid moves to make
    for (int i = 1; i <= b.holes(); i++){
        if (b.beans(s, i) != 0) //choses the pot with the greatest hole # value (rightmost) that has at least 1 bean
            badplayerMove = i;
    }
    return badplayerMove; //return the valid rightmost hole as the chosen move

    
//    vector<int> v; // a random player implementation
//    for (int i = 1; i <= b.holes(); i++){
//        if (b.beans(s, i) != 0) {
//            v.push_back(i);
//        }
//    }
//    int x = rand() % v.size();
//    return v[x];
    
//    int bestHole = -1; //my minimax player implementation
//    int value;
//    Board temp = b;
//    minimax(s, temp, bestHole, value, 0);
//    return bestHole;

    
}
//A BadPlayer is a computer player that chooses an arbitrary valid move and returns that choice. "Arbitrary" can be what you like: leftmost, nearest to pot, fewest beans, random, etc.. The point of this class is to have an easy-to-implement class that at least plays legally.


SmartPlayer::SmartPlayer(string name): Player(name){}


int SmartPlayer::chooseMove(const Board&b, Side s) const{
    node* root = new node; //create a node pointer
    Board *temp = new Board(b); //create a copy of the board
    root->possibleBoard = temp; //set root's board to temp
    createTree(root, 0, s); //create the tree of possibilities from root
// goes and sets the proper values for each node in the tree
    EvalTree(root, s);
    int chosenHole=-1;
    for (int i = 0; i < root->children.size(); i++){
        if (root->children[i]->value == root->value){ //if the value at root's child is the same as root's, set chosen hole to the holeNum value at that child
            chosenHole = root->children[i]->holeNum;
        }
        DeleteNodeAndItsChildren(root->children[i]);
    }
    delete root->possibleBoard;
    delete root;
    return chosenHole;
//int bestHole = -1; //minimax player implementation
//    int value;
//    Board temp = b;
//    minimax(s, temp, bestHole, value, 0);
//    return bestHole;
}

