//
//  Game.cpp
//  cs32 proj 3
//
//  Created by Janvi Bharucha on 5/19/23.
//

#include <stdio.h>
#include <algorithm>
#include "Game.h"
#include <limits>

using namespace std;
using std::swap;

Game::Game(const Board& b, Player* south, Player* north): mBoard(b), mSouth(south), mNorth(north), mCurrentTurn(SOUTH), moveResult(true) {}
//    Construct a Game to be played with the indicated players on a copy of the board b. The player on the south side always moves first.

Game::Game(const Game& other)
    : mBoard(other.mBoard), mCurrentTurn(other.mCurrentTurn), moveResult(other.moveResult) {
    if (dynamic_cast<HumanPlayer*>(other.mSouth))
        mSouth = new HumanPlayer(*dynamic_cast<HumanPlayer*>(other.mSouth));
    else if (dynamic_cast<BadPlayer*>(other.mSouth))
        mSouth = new BadPlayer(*dynamic_cast<BadPlayer*>(other.mSouth));
//    else if (dynamic_cast<SmartPlayer*>(other.mSouth))
//        mSouth = new SmartPlayer(*dynamic_cast<SmartPlayer*>(other.mSouth));

    if (dynamic_cast<HumanPlayer*>(other.mNorth))
        mNorth = new HumanPlayer(*dynamic_cast<HumanPlayer*>(other.mNorth));
    else if (dynamic_cast<BadPlayer*>(other.mNorth))
        mNorth = new BadPlayer(*dynamic_cast<BadPlayer*>(other.mNorth));
//    else if (dynamic_cast<SmartPlayer*>(other.mNorth))
//        mNorth = new SmartPlayer(*dynamic_cast<SmartPlayer*>(other.mNorth));
}

Game& Game::operator=(const Game& rhs) {
    if (this != &rhs) {
        Game temp(rhs);  // Create a temporary object using the copy constructor
        std::swap(temp.mNorth, mNorth);
        std::swap(temp.mSouth, mSouth);
        std::swap(temp.mBoard, mBoard);
        std::swap(temp.moveResult, moveResult);
        std::swap(temp.mCurrentTurn, mCurrentTurn);
    }
    return *this;
}

void Game::display() const{
    cout << endl;
    cout << "             P2: " << mNorth->name() << "            "<<endl;
    cout << endl;
    cout << "Hole #     0 ";
    for (int i = 1; i <= mBoard.holes(); i++)
        cout << i << " ";
    cout<<endl;
    cout << "          --";
    for (int i = 0; i<=mBoard.holes(); i++)
        cout <<"--";
    cout<<endl;
    cout << "             ";
    for (int i = 1; i <= mBoard.holes(); i++){
        cout << mBoard.beans(NORTH, i) <<" ";
    }
    cout << endl;
    cout<< "P2's Pot" << "   "<<mBoard.beans(NORTH, 0);
    for (int i = 1; i <= mBoard.holes(); i++)
        cout<<"  ";
    cout<<" "<<mBoard.beans(SOUTH,0)<<"  P1's Pot"<<endl;
    
    cout << "             ";
    for (int i = 1; i <= mBoard.holes(); i++){
        cout << mBoard.beans(SOUTH, i) <<" ";
    }
    cout << endl;
    cout << "          ";
    for (int i = 0; i<=mBoard.holes(); i++)
        cout <<"--";
    cout<<"--"<<endl;
    cout << "Hole #       ";
    for (int i = 1; i <= mBoard.holes(); i++)
        cout << i << " ";
    cout<<"0"<<endl;
    cout << endl;
    cout << "             P1: " << mSouth->name() << "            "<<endl;
    cout << endl;
}
void Game:: status(bool& over, bool& hasWinner, Side& winner) const{
    if (!moveResult){
        over = true;
        if (mBoard.beans(SOUTH, 0) == mBoard.beans(NORTH, 0))
            hasWinner = false;
        if (mBoard.beans(SOUTH, 0) > mBoard.beans(NORTH, 0)){
            hasWinner = true;
            winner = SOUTH;
        }
        if (mBoard.beans(SOUTH, 0) < mBoard.beans(NORTH, 0)){
            hasWinner = true;
            winner = NORTH;
        }
    }
    else {over = false;}
}
//    If the game is over (i.e., the move member function has been called and returned false), set over to true; otherwise, set over to false and do not change anything else. If the game is over, set hasWinner to true if the game has a winner, or false if it resulted in a tie. If hasWinner is set to false, leave winner unchanged; otherwise, set it to the winning side.


bool Game::move(Side s){
    bool capture = false;
    bool interactive = mNorth->isInteractive() || mSouth->isInteractive();
    int holes_that_have_beans = 0; //check that there is at least one hole that has one or more beans
    for (int i = 1; i <= mBoard.holes(); i++){
        if (mBoard.beans(s, i) != 0)
            holes_that_have_beans++; //set to the number of holes that are not empty
    }
    if (holes_that_have_beans == 0){ // if all the holes on that side are empty
        if (s == SOUTH){ //if SOUTH has no more beans in any of their holes add all of NORTH's beans to their pot
            for (int i = 1; i <= mBoard.holes(); i++){
                mBoard.moveToPot(NORTH, i, NORTH);
            }
        }
        if (s == NORTH){ //if NORTH has no more beans in any of their holes add all of SOUTH's beans to their pot
            for (int i = 1; i <= mBoard.holes(); i++){
                mBoard.moveToPot(SOUTH, i, SOUTH);
            }
        }
        moveResult = false;
        return false; //if all the holes are empty, return false, indicating that no move is possible
        }
    
    Side endSide;
    int endHole;
    int startHole;
    if (s == SOUTH){ // if South is moving
        startHole = mSouth->chooseMove(mBoard, SOUTH);
        mBoard.sow(SOUTH, startHole, endSide, endHole); // sow starting at the chosen hole
        if (mSouth->isInteractive() == false && s == SOUTH){
            
            cout << mSouth->name() << " started in their hole " << startHole << " and ended in ";
            if (endHole == 0)
                cout <<"their pot.";
            else if (endSide == SOUTH)
                cout <<mSouth->name()<<"'s hole "<<endHole<<endl;
            else
                cout<<mNorth->name()<<"'s hole "<<endHole<<endl;
        }
        if (endSide == SOUTH && endHole == 0 && holes_that_have_beans > 0 && !capture){ // if the turn ends at the
            display();
            holes_that_have_beans = 0; //check that there is at least one hole that has one or more beans
            for (int i = 1; i <= mBoard.holes(); i++){
                if (mBoard.beans(s, i) != 0)
                    holes_that_have_beans++; //set to the number of holes that are not empty
            }
            if (holes_that_have_beans != 0){ // if all the holes on that side are empty
                cout << "Nice! You ended in your pot! "<<mSouth->name()<<" go again!"<<endl;
            }
            if (!interactive) {
                cout << "Press ENTER to continue..." << endl;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            move(SOUTH);
        }
        if (endSide == SOUTH && endHole != 0 && mBoard.beans(SOUTH, endHole) == 1 && mBoard.beans(NORTH, endHole) != 0){ //if the player ended their turn on their side, not in their pot, and ended with a hole that had none before (now has one) and the opposing player's pot is not empty, then capture
            mBoard.moveToPot(SOUTH, endHole, SOUTH); //move the one bean in their hole to their pot
            mBoard.moveToPot(NORTH, endHole, SOUTH); //move the opponents beans in the opposite hole to their pot
            cout << "Nice Capture "<<mSouth->name()<<"!"<<endl;
            capture = true;
        }
        
    }
    else if (s == NORTH){ // if north moving
        startHole = mNorth->chooseMove(mBoard, NORTH);
        mBoard.sow(NORTH, startHole, endSide, endHole); //sow starting at the chosen hole
        if (mNorth->isInteractive() == false && s == NORTH){
            cout << mNorth->name() << " started in their hole " << startHole << " and ended in ";
            if (endHole == 0)
                cout <<"their pot.";
            else if (endSide == SOUTH)
                cout <<mSouth->name()<<"'s hole "<<endHole<<endl;
            else
                cout<<mNorth->name()<<"'s hole "<<endHole<<endl;
        }
        if (endSide == NORTH && endHole == 0 && holes_that_have_beans > 0 && !capture) {
            display();
            holes_that_have_beans = 0; //check that there is at least one hole that has one or more beans
            for (int i = 1; i <= mBoard.holes(); i++){
                if (mBoard.beans(s, i) != 0)
                    holes_that_have_beans++; //set to the number of holes that are not empty
            }
            if (holes_that_have_beans != 0){ // if all the holes on that side are empty
                cout << "Nice! You ended in your pot! "<<mNorth->name()<<" go again!"<<endl;
            }
           if (!interactive) {
            cout << "Press ENTER to continue..." << endl;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
            move(NORTH);
        }
        if (endSide == NORTH && endHole != 0 && mBoard.beans(NORTH, endHole) == 1 && mBoard.beans(SOUTH, endHole) != 0){//if the player ended their turn on their side, not in their pot, and ended with a hole that had none before (now has one) and the opposing player's pot is not empty, then capture
            mBoard.moveToPot(NORTH, endHole, NORTH); // move the one bean in their hole to their pot
            mBoard.moveToPot(SOUTH, endHole, NORTH); // move the opponents beans in the opposite hole to their pot
            cout << "Nice Capture "<<mNorth->name()<<"!"<<endl;
            capture = true;
        }
    }
    if (mBoard.beansInPlay(s) + mBoard.beansInPlay(opponent(s)) == 0){
        moveResult = false;
        return false;
    }
    moveResult = true;
    return true; // return true once move is complete
}
//    Attempt to make a complete move for the player playing side s. "Complete" means that the player sows the seeds from a hole and takes any additional turns required or completes a capture. Whenever the player gets an additional turn, you should display the board so someone looking at the screen can follow what's happening. If the move can be completed, return true; if not, because the move is not yet completed but side s has no holes with beans to pick up and sow, sweep any beans in s's opponent's holes into that opponent's pot and return false.

void Game::play() {
    bool interactive = mNorth->isInteractive() || mSouth->isInteractive();
    bool over = false;
    bool southTurn = true; //keep track of the current player's turn

        display();
    
    if (!interactive) {
        cout << "Press ENTER to begin..." << endl;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    while (!over) {
        if (southTurn) {
//            if (!over)
//                cout << mSouth->name() << "'s turn:" << endl;
            if (!move(SOUTH)){
                over = true;
                break;
            }
            if (!interactive) {
                cout << "Press ENTER to continue..." << endl;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }
        else {
//            if (!over)
//                cout << mNorth->name() << "'s turn:" << endl;
            if (!move(NORTH)){
                over = true;
                break;
            }
            if (!interactive) {
                cout << "Press ENTER to continue..." << endl;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }
        
        display();
        
        if (!interactive) {
            cout << "Press ENTER to continue..." << endl;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        southTurn = !southTurn; // Switch to the other player's turn
    }
    
    display();

    bool hasWinner;
    Side winner;
    status(over, hasWinner, winner);

    if (over && hasWinner && winner == NORTH)
        cout << mNorth->name() << " won!" << endl;
    else if (over && hasWinner && winner == SOUTH)
        cout << mSouth->name() << " won!" << endl;
    else if (over && !hasWinner)
        cout << "It's a tie!" << endl;
}

int Game::beans(Side s, int hole) const{
    return mBoard.beans(s, hole);
}

//  Play the game. Display the progress of the game in a manner of your choosing, provided that someone looking at the screen can follow what's happening. If neither player is interactive, then to keep the display from quickly scrolling through the whole game, it would be reasonable periodically to prompt the viewer to press ENTER to continue and not proceed until ENTER is pressed. (The ignore function for input streams is useful here.) Announce the winner at the end of the game. You can apportion to your liking the responsibility for displaying the board between this function and the move function.
