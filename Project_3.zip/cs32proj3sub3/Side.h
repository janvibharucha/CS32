//
//  Side.h
//  cs32 proj 3
//
//  Created by Janvi Bharucha on 5/19/23.
//

#ifndef Side_h
#define Side_h
#include <vector>

class Board;

enum Side { NORTH, SOUTH };

    const int NSIDES = 2;
    const int POT = 0;
    const int MAXDEPTH = 7;

    inline
    Side opponent(Side s)
    {
        return Side(NSIDES - 1 - s);
    }
struct node {
    node* parent = nullptr; //aka prev
    std::vector<node*> children; //aka next(s)
    Board *possibleBoard;
    int holeNum = -1;
    int value = 1234567; //evaluation value // initially set to a random default value that will likely never be reached
};


//void CreateAndEvalTree (const Board &b, Side s, int depth, node* current);
//It is Side s 's turn

//create a copy of the board called temp
// for every hole that has beans in temp board, create a child node of doing the move starting at that hole
    //call fakemove which should adjust the board so that a certain hole that is passed into it is the starting hole of a move that is made
        //if the turn ended in the pot, it should be set up so that fakemove recursively calls itself until it no longer ends in the pot, this ensures that the edited mBoard is edited up until the player can play no more
    //set the parent to the current node
    //set the possible board to temp
    //set the holeNume to the hole number in the parent that created that move
    //LEAVE VALUE AS DEFAULT (we recurse through and set them properly later
//recursively call the create portion of the function (aka need to make create a seperate helper function) until depth == maxValue
    //once the max depth is hit, this child becomes a leaf so we don't make any children. set the current's value to the evaluation function, then call the recursive function SetParentValue that sets all the values up to and including the root

//yayyy!!! Now time for evaluation --> setParentValue already goes through the entire tree and then finally sets the root to the best possible evaluation outcome for the entire tree

// ------------- THIS MAY BE FOR CHOOSEMOVE IN SMARTPLAYER -------------------
//create a node pointer root and set root ->possibleBoard to the board passed in
//call createTree
//to figure out what hole SmartPlayer should choose, it should take the root and iterate through all of it's children and choose the child which has the same value stored and then return the holeNum value stored at that child
// Since we have used the tree to choose the move we needed, we need to get rid of the tree. MAKE SURE TO FREE DAM --> iterate through the DeleteThese vector and delete each item (a pointer to a node in the tree) in the array. This will be done in the choosemove function at the end

void createTree(node* current, int depth, Side s);
void fakeMove(Board *mBoard, Side s, int hole);
int EvalTree(node* parent, Side s);
void DeleteNodeAndItsChildren(node* DeleteMe);

int evaluationFunction(Board *b);
void minimax(Side s, Board b, int& bestHole, int& value, int depth);


//what if I create a function that establishes a vector

#endif /* Side_h */

