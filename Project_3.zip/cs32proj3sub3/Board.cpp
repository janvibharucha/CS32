//
//  Board.cpp
//  cs32 proj 3
//
//  Created by Janvi Bharucha on 5/19/23.
//

#include <stdio.h>
#include "Board.h"

Board::Board(int nHoles, int nInitialBeansPerHole): NorthPot(POT), SouthPot(POT){
    if (nHoles <= 0) //checking for negative input for nHoles
        numHoles = 1;
    else
        numHoles = nHoles; //set mv numHoles to the nHoles if not negative or 0
    if (nInitialBeansPerHole < 0) // checking for negative input for nInitialBeansPerHole
        mInitialBeansPerHole = 0;
    else
        mInitialBeansPerHole = nInitialBeansPerHole; // set mv mInitialBeansPerHole to nInitialBeansPerHole if not negative
    
    for (int i = 0; i < numHoles; i++){ //create north and south vectors that each have numHoles # of holes that start with each hole (each index) that has a value of mInitialBeansperHole
        North_holes.push_back(mInitialBeansPerHole);
        South_holes.push_back(mInitialBeansPerHole);
    }
    
}

Board::Board(const Board& other) : numHoles(other.numHoles), mInitialBeansPerHole(other.mInitialBeansPerHole), NorthPot(other.NorthPot), SouthPot(other.SouthPot) {
    // Deep copy of North_holes vector
    North_holes.reserve(other.North_holes.size());
    for (int i = 0; i < other.North_holes.size(); i++) {
        North_holes.push_back(other.North_holes[i]);
    }

    // Deep copy of South_holes vector
    South_holes.reserve(other.South_holes.size());
    for (int i = 0; i < other.South_holes.size(); i++) {
        South_holes.push_back(other.South_holes[i]);
    }
}

Board& Board:: operator=(const Board& other) {
    if (this == &other) {
        return *this; // Self-assignment check
    }

    numHoles = other.numHoles;
    mInitialBeansPerHole = other.mInitialBeansPerHole;
    NorthPot = other.NorthPot;
    SouthPot = other.SouthPot;

    // Deep copy of North_holes vector
    North_holes.clear();
    North_holes.reserve(other.North_holes.size());
    for (int i = 0; i < other.North_holes.size(); i++) {
        North_holes.push_back(other.North_holes[i]);
    }

    // Deep copy of South_holes vector
    South_holes.clear();
    South_holes.reserve(other.South_holes.size());
    for (int i = 0; i < other.South_holes.size(); i++) {
        South_holes.push_back(other.South_holes[i]);
    }

    return *this;
}



int Board::holes() const{
    return numHoles; //returning the number of holes on one side
}

int Board::beans(Side s, int hole) const{
    if (hole < 0 || hole > numHoles) // checking for a valid input for hole
        return -1;
    if (s == NORTH){ //for the north side
        if (hole == 0)
            return NorthPot; //return the int value of the number of beans in the North pot
        return North_holes[hole-1]; // return the value at the index of the north vector
    }
    else { // for the south side
        if (hole == 0)
            return SouthPot; // return the int value of the number of beans in the South Pot
        return South_holes[hole-1]; // return the value at the index of the south vector
    }
}

int Board::beansInPlay(Side s) const{
    int bean_count = 0; // initialize bean counter to 0
    for (int i = 0; i < numHoles; i++){ // iterate through all of the holes on one side
        if (s == NORTH) // if the north side then sum the value at each index in the north vector
            bean_count += North_holes[i];
        
        else // if the south side then sum the value at each index in the south vector
            bean_count += South_holes[i];
    }
    
    return bean_count; // return the number of beans on that side
}
//    Return the total number of beans in all the holes on the indicated side, not counting the beans in the pot.

int Board::totalBeans() const{
    int bean_count = 0; // initialize bean counter to 0
    for (int i = 0; i < numHoles; i++){ // iterate through all of the holes
        // sum the value at each index in the north vector
        bean_count += North_holes[i];
        
        // sum the value at each index in the south vector
        bean_count += South_holes[i];
    }
    bean_count += SouthPot; // add the beans in the south pot
    bean_count += NorthPot; // add the beans in the north pot
    return bean_count; // return the number of beans on that side
}
//    Return the total number of beans in the game, including any in the pots.

bool Board:: sow(Side s, int hole, Side& endSide, int& endHole){
    if (hole <= 0 || hole > numHoles || beans(s, hole) <= 0) //check validity of passed in parameters
        return false;
    
    if (s == SOUTH){ // if south side
        int beans_in_hole = South_holes[hole-1]; // set the bean counter to the # of beans at the given hole
        South_holes[hole-1] = 0; // empty out the hole
        return moveSouth(beans_in_hole, hole, endSide, endHole); //sow all the beans and return true
    }
    else{ // if north side
        int beans_in_hole = North_holes[hole-1]; //set the bean counter to the # of beans at the given hole
        North_holes[hole-1] = 0; // empty out the hole
        return moveNorth(beans_in_hole, hole-2, endSide, endHole); // sow all the beans and return true
    }
}
//    If the hole indicated by (s,hole) is empty or invalid or a pot, this function returns false without changing anything. Otherwise, it will return true after sowing the beans: the beans are removed from hole (s,hole) and sown counterclockwise, including s's pot if encountered, but skipping s's opponent's pot. The function sets the parameters endSide and endHole to the side and hole where the last bean was placed. (This function does not make captures or multiple turns; different Kalah variants have different rules about these issues, so dealing with them should not be the responsibility of the Board class.)

bool Board::moveToPot(Side s, int hole, Side potOwner){
    if (hole <= 0 || hole > numHoles) //check validity of passed in parameters
        return false;
    if (s == NORTH){ // if side is north
        int hole_beans = North_holes[hole-1]; //store the number of beans at that certain hole
        North_holes[hole-1] = 0; // empty the hole
        if (potOwner == NORTH)
            NorthPot+= hole_beans; //add the stored bean count to the north pot
        if (potOwner == SOUTH)
            SouthPot+= hole_beans; //add the stored bean count to the south pot
        return true;
    }
    else { // if side is south
        int hole_beans = South_holes[hole-1]; // store the number of beans at the certain hole
        South_holes[hole-1] = 0; // empty the hole
        if (potOwner == NORTH)
            NorthPot+= hole_beans; // add the stored bean count to the north pot
        if (potOwner == SOUTH)
            SouthPot+= hole_beans; // add the stored bean count to the south pot
        return true;
    }
}
//    If the indicated hole is invalid or a pot, return false without changing anything. Otherwise, move all the beans in hole (s,hole) into the pot belonging to potOwner and return true.

bool Board::setBeans(Side s, int hole, int beans){ 
    if (hole < 0 || hole > numHoles || beans < 0) //check validity of passed in parameters
        return false;
    if (s == NORTH){ // north side
        if (hole == 0) // if pot
            NorthPot = beans; //set the pot to beans
        else
            North_holes[hole-1] = beans; // set the hole to beans
    }
    if (s == SOUTH){ // south side
        if (hole == 0)
            SouthPot = beans; // set pot to beans
        else
            South_holes[hole-1] = beans; // set the hole to beans
    }
    return true;
}
//    If the indicated hole is invalid or beans is negative, this function returns false without changing anything. Otherwise, it will return true after setting the number of beans in the indicated hole or pot to the value of the third parameter. (This could change what beansInPlay and totalBeans return if they are called later.) This function exists solely so that we and you can more easily test your program: None of your code that implements the member functions of any class is allowed to call this function directly or indirectly. (We'll show an example of its use below.)


bool Board::moveSouth (int beans_in_hole, int hole, Side& endSide, int& endHole){
    if (beans_in_hole == 0){
        return true; // since our sow function already checks that the number of beans at a hole passed in cannot be 0 already, the only time the beans_in_hole function can = 0 is if that is done so by moveSouth's doing, that means the function can stop running and return true
    }
    endSide = SOUTH; // necessary? set values so no undefined behavior
    endHole = hole; // necessary? set values so no undefined behavior
    
    while(hole < numHoles && beans_in_hole != 0){ //check that hole is a valid index and that we still have enough beans to sow
        endSide = SOUTH; //since we are on the south side set endSide to south
        South_holes[hole]++; //add one to the given hole
        beans_in_hole--; // decrement the bean counter
        endHole = hole+1; //set endHole to the current hole #
        hole++; // increment the hole value
    }
    hole --; // decrement hole so it is still a valid index
    
    if (beans_in_hole != 0){
        SouthPot++; //add one to the South pot
        endHole = 0; //set endHole to the hole# of SouthPot
        beans_in_hole--; //decrement the bean counter
    }
    
    while (hole >= 0 && beans_in_hole!=0){
        endSide = NORTH; // since we are on the north side set endSide to north
        North_holes[hole]++;// add one to the given hole
        beans_in_hole--; // decrement the bean counter
        endHole = hole+1; // set endHole to the current hole # (will never = 0 so don't have to worry about it returning the hole # of the North Pot)
        hole--; // decrement the hole since North is traversed backwards
    }
    hole++; // increment hole so it is still a valid index
    return moveSouth(beans_in_hole, hole, endSide, endHole); // recursively call the function until there are no more beans left to sow
}

bool Board::moveNorth (int beans_in_hole, int hole, Side& endSide, int& endHole){
    if (beans_in_hole <= 0){
        return true; // since our sow function already checks that the number of beans at a hole passed in cannot be 0 already, the only time the beans_in_hole function can = 0 is if that is done so by moveNorth's doing, that means the function can stop running and return true
    }
    
    endSide = NORTH; // necessary? set value so no undefined behavior
    endHole = hole; // necessary? set value so no undefined behavior
    while (hole >= 0 && beans_in_hole!=0){ //check that hole is a valid index and that we still have enough beans to sow
        endSide = NORTH; // since we are on the north side set endSide to north
        North_holes[hole]++; // add one to the given hole
        beans_in_hole--; // decrement the bean counter
        endHole = hole+1; // set endHole to the current hole #
        hole--; // decrement the hole since North is traversed backwards
    }
    hole++; // increment hole so it is still a valid index
    
    if (beans_in_hole != 0){
        NorthPot++; //add one to the North pot
        endHole = 0; //set endHole to the hole# of NorthPot
        beans_in_hole--; //decrement the bean counter
    }
    
    while(hole < numHoles && beans_in_hole != 0){ //check that hole is a valid index and that we still have enough beans to sow
        endSide = SOUTH; //since we are on the south side set endSide to south
        South_holes[hole]++; // add one to the given hole
        beans_in_hole--; // decremen the bean counter
        endHole = hole+1; // set endHole to the current hole # will never = 0 so don't have to worry about it returning the hole # of the South Pot)
        hole++; // increment hole
    }
    hole--; // decrement hole so it is still a valid index
    return moveNorth(beans_in_hole, hole, endSide, endHole);
}
