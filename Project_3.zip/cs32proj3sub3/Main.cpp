//
//  main.cpp
//  cs32 proj 3
//
//  Created by Janvi Bharucha on 5/19/23.
//

#include <iostream>
#include "Game.h"
#include "Board.h"
#include "Side.h"
#include <cassert>
using namespace std;

int main() {
    


    
    Board b(6, 4);
    SmartPlayer AItrial("robot");
    SmartPlayer ROBO("robo");
    HumanPlayer southernplayer("Janvi");
//    BadPlayer north_bad_player("Northern baddie");
//    BadPlayer south_bad_player("Southern baddie");
    //Player *northern_baddie = &north_bad_player;
//    Player *southern_baddie = &south_bad_player;
    Player *north_p = &southernplayer;
    Player *south_p= &AItrial;
//    int northwins = 0;
//    int southwins = 0;
//    for (int i = 0; i < 10; i++) {
//        Game g(b, south_p, north_p);
//        int x = g.play();
//        if (x == 0) northwins++;
//        if (x == 1) southwins++;
//    }
//    cout << "north wins: " << northwins << ", south wins: " << southwins << endl;
    Game g(b, south_p, north_p);
    g.play();
    
    
}

int evaluationFunction(Board* b){
    int nonEmptyHoleCount=0;
    for (int i = 1; i <= b->holes(); i++){
        if (b->beans(NORTH, i) != 0)
            nonEmptyHoleCount++;
    }
    return (0.2*(b->beans(NORTH, 1)) + 0.1*(b->beansInPlay(NORTH)) + 0.7*(nonEmptyHoleCount) + (b->beans(NORTH,0) - 0.7*(b->beans(SOUTH, 0))) + 0.7*(b->beans(NORTH,0) - (b->beans(SOUTH, 0)))+ 0.2*(b->beans(NORTH, 0)-(b->totalBeans()/2)) - 0.3*((b->beans(SOUTH, 0) - b->totalBeans()/2)));
    
}

void fakeMove(Board *mBoard, Side s, int hole) {
    Side endSide;
    int endHole;
    if (s == SOUTH) { // if South is moving
        mBoard->sow(SOUTH, hole, endSide, endHole); // sow starting at the chosen hole

        if (endSide == SOUTH && endHole != 0 && mBoard->beans(SOUTH, endHole) == 1 && mBoard->beans(NORTH, endHole) != 0){ //if the player ended their turn on their side, not in their pot, and ended with a hole that had none before (now has one) and the opposing player's pot is not empty, then capture
            mBoard->moveToPot(SOUTH, endHole, SOUTH); //move the one bean in their hole to their pot
            mBoard->moveToPot(NORTH, endHole, SOUTH); //move the opponents beans in the opposite hole to their pot
        }

    }
    else if (s == NORTH){ // if north moving
        mBoard->sow(NORTH, hole, endSide, endHole); //sow starting at the chosen hole

        if (endSide == NORTH && endHole != 0 && mBoard->beans(NORTH, endHole) == 1 && mBoard->beans(SOUTH, endHole) != 0){//if the player ended their turn on their side, not in their pot, and ended with a hole that had none before (now has one) and the opposing player's pot is not empty, then capture
            mBoard->moveToPot(NORTH, endHole, NORTH); // move the one bean in their hole to their pot
            mBoard->moveToPot(SOUTH, endHole, NORTH); // move the opponents beans in the opposite hole to their pot
        }
    }
    return;
}

void createTree(node* current, int depth, Side s){
    if (depth == MAXDEPTH) { //at a leaf
        current->value = evaluationFunction(current->possibleBoard);
        return; //return
    }
    for (int i = 1; i <= current->possibleBoard->holes(); i++){
        if (current->possibleBoard->beans(s, i) != 0) { //if a move at that hole is possible
            Board* tempBoard = new Board (*(current->possibleBoard)); //create a new board
            fakeMove(tempBoard, s, i); //move on the new board
            node* tempNode = new node; //allocate new node
            tempNode->possibleBoard = tempBoard; //set the possibleBoard to the new board
            tempNode->parent = current; // set the new nodes parent to the current
            tempNode->holeNum = i; //set the hole that created that board to holeNum
            //DeleteMe.push_back(tempNode); //add to the delete vector
            current->children.push_back(tempNode); //add as a child of current
            createTree(tempNode, depth+1, opponent(s)); //create a tree now for the opponents turn
        }
    }
    if (current->children.size() == 0) { //at a leaf
        current->value = evaluationFunction(current->possibleBoard);
        return;
    }
}

int EvalTree(node* parent, Side s) {
    if (parent->children.size() == 0) {
        return parent->value; //if a leaf then return the parent's value
    }
    if (parent->value == 1234567) {//if set to the default value still
        parent->value = EvalTree(parent->children[0], opponent(s)); //evaluate
        for (int i = 0; i < parent->children.size(); i++) {
            parent->children[i]->value = EvalTree(parent->children[i], opponent(s));
            if (parent->value == 1234567) //hmm...should never enter
                return parent->children[i]->value;
            else if (s == NORTH){ //NORTH wants the greatest possible value, south is the parent
                if (parent->value < parent->children[i]->value) { //change value based on the Side Preference of the evaluation (NORTH prefers higher eval values, South prefers lower eval values)
                    parent->value = parent->children[i]->value;
                }
            }
            else {
                if (parent->value > parent->children[i]->value) {
                    parent->value = parent->children[i]->value;
                }
            }
        }
    }
    return parent->value;

}


void DeleteNodeAndItsChildren(node* DeleteMe) {
    for (int i = 0; i < DeleteMe->children.size(); i++) { //goes through and calls the function on all of the children
        DeleteNodeAndItsChildren(DeleteMe->children[i]);
    }
    delete DeleteMe->possibleBoard;
    delete DeleteMe;
}

//void minimax(Side s, Board b, int& bestHole, int& value, int depth) {
//    if (depth == MAXDEPTH) {
//        value = evaluationFunction(b);
////        bestHole = -1;
//        return;
//    }
//    bool possibleMove = false;
//    for (int i = 1; i <= b.holes(); i++){
//        if (b.beans(s, i) != 0) {
//            possibleMove = true;
//            Board copy = b;
//            Side endSide;
//            int endHole;
//            copy.sow(s, i, endSide, endHole);
//            if (endHole != 0 && copy.beans(s, endHole) == 1 && copy.beans(opponent(s), endHole) != 0){
//                copy.moveToPot(s, endHole, s);
//                copy.moveToPot(opponent(s), endHole, s);
//            }
//
////            if (endHole == 0) {
////                minimax(s, copy, bestHole, value, depth);
////            }
//            int h2;
//            int v2;
//            minimax(opponent(s), copy, h2, v2, depth + 1);
//            copy = b;
//            if (v2 < value && s == SOUTH) {
//                bestHole = i;
//                value = v2;
//            }
//            if (v2 > value && s == NORTH) {
//                bestHole = i;
//                value = v2;
//            }
////            cout << bestHole << endl;
//        }
//    }
//    if (!possibleMove) {
//        value = evaluationFunction(b);
//        bestHole = -1;
//        return;
//    }
//}
