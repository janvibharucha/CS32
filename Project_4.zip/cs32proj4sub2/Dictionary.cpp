// Dictionary.cpp

// This is a correct but horribly inefficient implementation of Dictionary
// functionality.  Your job is to change DictionaryImpl to a more efficient
// correct implementation.  You can change it any way you like, subject to
// restrictions in the spec (e.g., that the only C++ library container you
// are allowed to use are vector, list, stack, and queue (and string); if you
// want anything fancier, implement it yourself).

#include "Dictionary.h"
#include <string>
#include <list>
#include <cctype>
#include <utility>  // for swap
#include <algorithm>
#include <iostream>
#include <functional>

using namespace std;

void removeNonLetters(string& s);

class DictionaryImpl
{
  public:
    DictionaryImpl(int MAXBUCKETS);
    ~DictionaryImpl();
    void insert(string word);
    void lookup(string letters, void callback(string)) const;
  private:
    vector <list <string>> v;
    int maxBuckets;
    int hasher (string unsortedWord) const;
};

DictionaryImpl::DictionaryImpl(int MAXBUCKETS):maxBuckets(MAXBUCKETS){} //constructor
DictionaryImpl::~DictionaryImpl(){}

int DictionaryImpl::hasher(string unsortedWord) const{
    removeNonLetters(unsortedWord);
    string sortedWord = unsortedWord;
    transform(sortedWord.begin(), sortedWord.end(), sortedWord.begin(), ::tolower); //converting all the letter in the string to lowercase to ensure that all values for letters upper/lowercase are the same and therefore accounted for
    sort(sortedWord.begin(), sortedWord.end()); //sorting the characters in the string in ascending order of ASCII values

    size_t hashValue = hash<string>{}(sortedWord); //hash value
    return (hashValue % maxBuckets);  // modulo to limit the bucket count
}


void DictionaryImpl::insert(string word)
{
    removeNonLetters(word); //only letters in the word
    int index = hasher(word); //return value of the hash function is the index in the vector
    if (index >= v.size()){ //if the index does not exist in the vector, then resize the vector so that it does exist
//        v.insert(v.end(), index - v.size() + 1, list<string>());
        if (index >= maxBuckets)
            v.resize(maxBuckets);
        else
            v.resize(index +1);
    }

    v[index].push_back(word); //add the word to the list at that index of the vector
}

void DictionaryImpl::lookup(string letters, void callback(string)) const
{
    if (callback == nullptr)
        return;

    removeNonLetters(letters);
    if (letters.empty())
        return;
    sort(letters.begin(), letters.end()); //sorting the characters in the string in ascending order of ASCII values
    
    int potential_index = hasher(letters);
    if (potential_index >= v.size()) //if the hashed index does not exist in the vector then do nothing, since there are no words in the dictionary that have the same letters and only those letters as what is passed in, therefore callback should be called on nothing
        return;
    for (list<string>::const_iterator wordp = v[potential_index].begin(); wordp != v[potential_index].end(); wordp++){
        string sortedWord = *wordp;
        sort(sortedWord.begin(), sortedWord.end());
        if (letters == sortedWord)
            callback(*wordp);
    }
   
}

void removeNonLetters(string& s)
{
    string::iterator to = s.begin();
    for (string::const_iterator from = s.begin(); from != s.end(); from++)
    {
        if (isalpha(*from))
        {
            *to = tolower(*from);
            to++;
        }
    }
    s.erase(to, s.end());  // chop everything off from "to" to end.
}


//******************** Dictionary functions ******************************

// These functions simply delegate to DictionaryImpl's functions
// You probably don't want to change any of this code

Dictionary::Dictionary(int maxBuckets)
{
    m_impl = new DictionaryImpl(maxBuckets);
}

Dictionary::~Dictionary()
{
    delete m_impl;
}

void Dictionary::insert(string word)
{
    m_impl->insert(word);
}

void Dictionary::lookup(string letters, void callback(string)) const
{
    m_impl->lookup(letters,callback);
}

