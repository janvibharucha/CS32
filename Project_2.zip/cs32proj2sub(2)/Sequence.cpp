//
//  Sequence.cpp
//  cs32 proj 2
//
//  Created by Janvi Bharucha on 4/19/23.
//
#include <stdio.h>
#include <iostream>
#include "Sequence.h"
using namespace std;

Sequence::Sequence() {
    head = nullptr; // set head to null
    tail = nullptr; // set tail to null
    numNodes = 0; // start the count of nodes as 0
}

Sequence::~Sequence() {
    if (head == nullptr) //it is still an empty list
        return;
    
    Node* p = head;
    while (p != nullptr) {
        Node* temp = p->next; // temp variable for next value
        delete p; // free dynamically allocated memory
        p = temp;
    }
}

Sequence& Sequence::operator= (const Sequence& value){
    if (this != &value) { // if the values are not already the same
        Sequence temp(value);
        swap (temp); // sets this sequence to have the value of temp (and vis versa)
    }
    return *this;
}

Sequence::Sequence(const Sequence& other) {
    numNodes = other.numNodes;
    
    if (other.numNodes == 0) { //if other set is empty then we copy over an empty sequence
        head = nullptr;
        tail = nullptr;
        numNodes = 0;
        return;
    }
    
    head = new Node; //create a new node
    head->prev = nullptr; //set previous to null since it is the start of the sequence
    
    Node* ptr = head; //create pointers to nodes to help iterate through the sequences
    Node* other_ptr = other.head;
    
    while (other_ptr-> next != nullptr) {
        Node* nNode = new Node;
        ptr -> value = other_ptr -> value;
        ptr -> next = nNode;
        nNode->prev = ptr; // set the next node's prev to ptr
        
        ptr = nNode; // move ptr to the next node
        other_ptr = other_ptr -> next; // increment other_ptr
    }
    ptr->value = other_ptr->value; // copies last value into p
    tail = ptr;
    ptr->next = nullptr; //sets the last node to null
}

bool Sequence::empty() const{
    return numNodes ==0; // returns true if numNodes = 0 and false otherwise
}

int Sequence::size() const {
    return numNodes; // returns the node count
}

int Sequence::insert(int pos, const ItemType& value) {
    if (pos < 0 || pos > size()) // checks that pos is a value within the range of the size
        return -1;
    
    Node *n = new Node; //allocate a new node
    n->value = value; // set the value of the new node to the value passed in
    
    if (pos == 0) { // when starting from the beginning of the sequence with an insertion
        n->next = head; //n becomes the new head, so shift the sequence
        if (head != nullptr)
            head->prev = n; // link head to n
        head = n; //set n as the new head of the sequence
        if (tail == nullptr)
            tail = n;
        numNodes++; //increment the number of nodes
        return pos; //return the position 0
    }
    
    Node* c = head; //create a current node
    
    for (int i = 0; i < pos-1; i++) // do I need the -1? (i<pos -1)
        if (c->next != nullptr)
            c = c->next; //iterate through the sequence
    
    n->next = c->next; //link n into the sequence
    n->prev = c;
    
    if (c->next == nullptr)
        tail = n;
    else
        c->next->prev = n;
    c->next = n;
    numNodes++; //increment the number of nodes
    return pos; // return the position inserted at
}


int Sequence::insert(const ItemType& value) {
    Node *c = head; //create a node pointer to head
    int p = 0; //set p to 0
    if (numNodes == 0) { //if sequence is empty
        insert(0, value); //insert the value at the first position
        return p; //return 0
    }
    
    for (; p < numNodes; p++) {
        if (c != nullptr && c->value >= value) { //as long as c is not at the end and the value at c is greater than or equal to the value passed in insert the value at p
            insert (p, value);
            return p; //return the position
        }
        c = c->next; //increment c
    }
    insert (p, value);
    return p;
}

bool Sequence::erase(int pos){
    if (pos < 0 || pos >= size()) //checks the position is in the range of the size
        return false;
    Node* n = head; //initialize pointer to the head of the sequence
    if (pos == 0) { //if the position passed in is the beginning of the sequence, delete head and shift the sequence left
        head = n->next;
        if (head != nullptr)
            head->prev = nullptr;
        delete n;
        numNodes--; //decrement the node counter
        return true;
    }
    for (int i = 0; i < pos; i++) {//pos-1 or pos?
        if (n->next != nullptr) {
            n = n->next; //itterate through the sequence
        }
    }
    if (n->next != nullptr) {
        n->prev->next = n->next; //update links of the surrounding nodes
        n->next->prev = n->prev;
    }
    else {
        n->prev->next = nullptr;
    }
    delete n;
    numNodes--; //decrement the node counter
    return true;
}

int Sequence::remove(const ItemType& value){
    int items_removed = 0;
            int pos = find(value); // find the position of the first occurrence of value
            
            while (pos != -1) { // while value is found in the sequence
                erase(pos); // remove the value at that position
                items_removed++; // increment the count of items removed
                pos = find(value); // find the position of the next occurrence of value
            }
    
            return items_removed; // return the count of items removed


}

bool Sequence::get(int pos, ItemType& value) const {
    if (pos < 0 || pos >= size()) //check that pos is properly within the specified bounds
        return false;
    Node* p = head;
    int i = 1;
    while (i <= pos) // iterate until position point
    {
        if (p-> next != nullptr)
            p = p->next; // point to next node
        i++; // increment i value
    }
    value = p->value; // set value to the value of p
    return true;
}

bool Sequence::set(int pos, const ItemType& value){
    if (pos < 0 || pos >= size()) //check that pos is properly within the specified bounds
        return false;
    Node* n = head; //create a new node pointer that starts at the head
    for (int i = 0; i < pos; i++)
        if (n->next != nullptr)
            n = n -> next; //iterate through the sequence
    n->value = value; //set the value at the node to the value passed in
    return true;
}

int Sequence::find(const ItemType& value) const{
    int p = 0; //start position counter at position 0
    Node* n = head; // create a new node pointer that starts at the head
    
    while (n != nullptr){
       if (n->value == value)
           return p;
        p++; //increment the position counter
        n = n->next; //iterate through the sequence
    }
    return -1;
}

void Sequence::swap(Sequence& other){
        // Swap head pointers
       Node* temp = head;
       head = other.head;
       other.head = temp;

       // Swap tail pointers
       temp = tail;
       tail = other.tail;
       other.tail = temp;

       // Swap sizes
       int tempSize = numNodes;
       numNodes = other.numNodes;
       other.numNodes = tempSize;
}

int subsequence(const Sequence& seq1, const Sequence& seq2) {
    if (seq2.size() == 0 || seq2.size() > seq1.size()) {
        // If seq2 is empty or if it is bigger than seq1, subsequence can't be found so return -1.
        return -1;
    }

    ItemType first; // will hold the first item in the subsequence that matches seq1.
    ItemType x;
    ItemType current;
    ItemType next;
    seq2.get(0, first);

    for (int i = 0; i <= seq1.size() - seq2.size(); i++) {
        // searches for the first item in the subsequence in seq1.
        seq1.get(i, current);
        if (current == first) {
            // if the first item matches, then check for the rest of the subsequence.
            bool match = true;
            for (int j = 1; j < seq2.size(); j++) {
                seq1.get(i+j, next);
                seq2.get(j, x);
                if (next != x) {
                    match = false;
                    break;
                }
            }
            if (match) {
                // the whole subsequence has been found, so return the starting position.
                return i;
            }
        }
    }

    // the subsequence was not found so default to return -1
    return -1;
}

void concatReverse(const Sequence& seq1, const Sequence& seq2, Sequence& result){
    Sequence r; // new sequence
    ItemType x;
    ItemType y;
    
    for (int i = 0; i < (seq1.size()+seq2.size()); i++){
        r.insert(i, 0); //set the size of r correctly
    }

    // Reverse the items in seq2 and add them to the result sequence
        for (int i = 0; i < seq2.size(); i++) {
            seq2.get(i, x);
            r.set(r.size()-i-1, x);
        }
    // Reverse the items in seq1 and add them to the result sequence
    for (int i = 0; i < seq1.size(); i++) {
            seq1.get(i, y);
            r.set(r.size()-i-seq2.size()-1, y);
        }
    result = r;
}
    


